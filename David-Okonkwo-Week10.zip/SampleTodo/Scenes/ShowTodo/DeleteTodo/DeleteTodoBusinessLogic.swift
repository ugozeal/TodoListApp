//
//  DeleteTodoInteractor.swift
//  SampleTodo
//
//  Created by David U. Okonkwo on 10/18/20.
//

import Foundation

protocol DeleteTaskBusinessLogic {
    func deleteTask(todo: [TodoModel])
}
