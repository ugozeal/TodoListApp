# David Okonkwo- TODO App with VIP

> Project demo App link : https://drive.google.com/file/d/160KuocBDrsBmUZpqie6CUhVEZV5ExZot/view?usp=sharing

### I implemented the VIP 
### Using VIP I implemented the CRUD Methods
### I think I should still work on my naming convention
### I also think i need a deeper understanding of the VIP Architecture
